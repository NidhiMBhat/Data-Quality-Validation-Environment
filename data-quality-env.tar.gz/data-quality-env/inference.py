"""
Inference Script — Data Quality OpenEnv
========================================

Runs an LLM agent against all three tasks and emits the mandatory
[START] / [STEP] / [END] log lines expected by the judge harness.

Environment variables:
  API_BASE_URL     LLM API endpoint  (default: https://api.openai.com/v1)
  MODEL_NAME       Model identifier  (default: gpt-4o-mini)
  HF_TOKEN         API key (Hugging Face token or OpenAI key)
  ENV_URL          Running env server (default: http://localhost:7860)

Usage:
  python inference.py

Stdout format (one line each, no embedded newlines):
  [START] task=<task_id> env=data-quality-env model=<model>
  [STEP]  step=<n> action=<json> reward=<0.00> done=<true|false> error=<msg|null>
  [END]   success=<true|false> steps=<n> rewards=<r1,r2,...>
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
from typing import Any, Dict, List, Optional

import requests
from openai import OpenAI

# ── configuration ─────────────────────────────────────────────────────────────

API_BASE_URL: str = os.getenv("API_BASE_URL", "https://api.openai.com/v1")
MODEL_NAME:   str = os.getenv("MODEL_NAME",   "gpt-4o-mini")
HF_TOKEN:     str = os.getenv("HF_TOKEN",     "")
ENV_URL:      str = os.getenv("ENV_URL",       "http://localhost:7860")

ENV_NAME = "data-quality-env"
TASKS    = ["clean_nulls", "normalize_formats", "reconcile_tables"]
MAX_STEPS = 14   # leave 1 slot for forced submit

client = OpenAI(api_key=HF_TOKEN or "no-key", base_url=API_BASE_URL)

# ── prompts ───────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """\
You are a data quality agent. At each turn you receive the current state of a
dataset with issues and you must decide on ONE action to fix things.

Reply with ONLY a JSON object — no markdown, no explanation, no extra text.

Valid action shapes:
  {"operation": "fill_null",         "column": "<col>", "strategy": "mean|median|mode|<value>"}
  {"operation": "drop_duplicates",   "subset": ["col1", "col2"]}
  {"operation": "normalize_column",  "column": "<col>"}
  {"operation": "delete_row",        "row_id": <int>}
  {"operation": "set_value",         "row_id": <int>, "column": "<col>", "value": <any>}
  {"operation": "submit"}

Rules:
- Fix the most impactful issue first.
- When all issues are resolved (issues_remaining == 0) call submit immediately.
- If you have used more than half your allowed steps and progress is slow, submit.
"""


def _fmt_obs(obs: Dict[str, Any]) -> str:
    lines: List[str] = [
        f"=== STEP {obs['step_count']}/{obs['max_steps']} | "
        f"ISSUES REMAINING: {obs['issues_remaining']} | "
        f"TASK: {obs['task_id']} ===",
    ]
    if obs["issues_found"]:
        lines.append("\nCURRENT ISSUES (up to 12 shown):")
        for issue in obs["issues_found"][:12]:
            lines.append(f"  • {issue}")
    lines.append("\nDATASET (first 6 rows):")
    for row in obs["data"][:6]:
        lines.append(f"  {row}")
    lines.append("\nAVAILABLE ACTIONS:")
    for a in obs["available_actions"]:
        lines.append(f"  {a}")
    return "\n".join(lines)


def _call_llm(messages: List[Dict]) -> str:
    resp = client.chat.completions.create(
        model=MODEL_NAME,
        messages=messages,
        max_tokens=256,
        temperature=0.0,
    )
    return resp.choices[0].message.content.strip()


def _parse_action(text: str) -> Dict[str, Any]:
    text = text.strip()
    # Strip markdown fences if present
    if text.startswith("```"):
        lines = text.splitlines()
        text = "\n".join(lines[1:-1]).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*?\}", text, re.DOTALL)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                pass
    return {"operation": "submit"}  # safe fallback


def _wait_for_server(timeout: int = 30) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            r = requests.get(f"{ENV_URL}/health", timeout=3)
            if r.status_code == 200:
                return
        except requests.RequestException:
            pass
        time.sleep(2)
    raise RuntimeError(f"Environment server at {ENV_URL} did not become ready in {timeout}s")


def run_episode(task_id: str) -> Dict[str, Any]:
    # ── reset ────────────────────────────────────────────────────────────────
    resp = requests.post(f"{ENV_URL}/reset", json={"task_id": task_id}, timeout=10)
    resp.raise_for_status()
    obs: Dict[str, Any] = resp.json()

    print(f"[START] task={task_id} env={ENV_NAME} model={MODEL_NAME}", flush=True)

    messages: List[Dict] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                f"TASK DESCRIPTION:\n{obs['task_description']}\n\n"
                f"SCHEMA:\n{json.dumps(obs['schema_info'], indent=2)}\n\n"
                f"CONSTRAINTS:\n" + "\n".join(obs["constraints"])
            ),
        },
    ]

    step_rewards: List[float] = []
    step_n = 0
    done = False
    last_error: Optional[str] = None

    while not done and step_n < MAX_STEPS:
        step_n += 1

        # Add current observation to conversation
        messages.append({"role": "user", "content": _fmt_obs(obs)})

        # Get action from LLM
        try:
            raw_action = _call_llm(messages)
            action_dict = _parse_action(raw_action)
        except Exception as exc:
            action_dict = {"operation": "submit"}
            raw_action  = json.dumps(action_dict)
            last_error  = str(exc)

        # Add assistant turn to history
        messages.append({"role": "assistant", "content": raw_action})

        # Execute action
        try:
            resp = requests.post(
                f"{ENV_URL}/step", json=action_dict, timeout=10
            )
            resp.raise_for_status()
            result      = resp.json()
            obs         = result["observation"]
            reward_val  = float(result["reward"]["score"])
            done        = bool(result["done"])
            info        = result.get("info", {})
            last_error  = info.get("error")
        except Exception as exc:
            reward_val = 0.0
            done       = True
            last_error = str(exc)

        step_rewards.append(reward_val)
        error_str = last_error if last_error else "null"
        done_str  = "true" if done else "false"
        action_str = json.dumps(action_dict, separators=(",", ":"))

        print(
            f"[STEP] step={step_n} action={action_str} "
            f"reward={reward_val:.2f} done={done_str} error={error_str}",
            flush=True,
        )

        if reward_val >= 1.0:
            done = True

    # Force submit if we ran out of steps without terminating
    if not done:
        step_n += 1
        try:
            resp = requests.post(
                f"{ENV_URL}/step", json={"operation": "submit"}, timeout=10
            )
            result     = resp.json()
            reward_val = float(result["reward"]["score"])
        except Exception:
            reward_val = step_rewards[-1] if step_rewards else 0.0
        step_rewards.append(reward_val)
        print(
            f'[STEP] step={step_n} action={{"operation":"submit"}} '
            f"reward={reward_val:.2f} done=true error=null",
            flush=True,
        )

    final_score   = step_rewards[-1] if step_rewards else 0.0
    final_success = final_score >= 1.0
    rewards_str   = ",".join(f"{r:.2f}" for r in step_rewards)
    success_str   = "true" if final_success else "false"

    print(
        f"[END] success={success_str} steps={step_n} rewards={rewards_str}",
        flush=True,
    )

    return {
        "task":        task_id,
        "success":     final_success,
        "steps":       step_n,
        "final_score": final_score,
    }


def main() -> None:
    print(f"# Waiting for environment server at {ENV_URL} …", flush=True)
    _wait_for_server()

    results: List[Dict] = []
    for task_id in TASKS:
        try:
            result = run_episode(task_id)
        except Exception as exc:
            print(f"[END] success=false steps=0 rewards=0.00", flush=True)
            result = {"task": task_id, "success": False, "steps": 0, "final_score": 0.0}
            print(f"# ERROR during task {task_id}: {exc}", file=sys.stderr)
        results.append(result)
        print()

    print("# ═══════════════════════════════════════")
    print("# BASELINE RESULTS SUMMARY")
    print("# ═══════════════════════════════════════")
    for r in results:
        print(
            f"# Task: {r['task']:<25}  Score: {r['final_score']:.4f}  "
            f"Steps: {r['steps']:>2}  Success: {r['success']}"
        )
    avg = sum(r["final_score"] for r in results) / len(results)
    print(f"# Average score: {avg:.4f}")


if __name__ == "__main__":
    main()
